<?php
$server = "localhost";
$dbuser = "root";
$dbpassword = "";
$dbname = "practdb";
$basedir = "localhost/pract/";
$projectname = "pract";
?>