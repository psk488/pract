<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title>user info</title>
    </head>
    <body>
        <h1>User Registration </h1>
                <form method="post">
                    <div class="form-group">
                            <label for="Inputfname">First Name:</label>
                            <input type="text" name="fname" class="form-control" id="Inputfnameame" placeholder="Enter First name">                           
                    </div> 
                    <div class="form-group">
                            <label for="Inputusername">Email:</label>
                            <input type="email" name="email" class="form-control" id="Inputusername"  placeholder="Enter email"/>
                    </div>   

                        <div class="form-group">
                            <label for="Inputpwd">Password</label>
                            <input class="form-control" type="password" name="password" placeholder="Password">
                        </div>


                        <div class="form-group">
                            <button type="submit" name="submit" class="btn btn-default">Submit</button>
                            <button type="reset" name="reset" class="btn btn-default">Reset</button>
                        </div>
                </form>
        <p>already registered user can directly <a href="login.php">Login</a> Here...</p>
    </body>
</html>
 <?php
        require 'config.php';
        require 'dbconfig.php';
        //isset():used to chk whether the variable is set or not
if (isset($_POST['submit']))
    {
    $firstname = $_POST['fname'];
    $email = $_POST['email'];
    $password = $_POST['password'];
   $sql = "INSERT INTO login_tbl (fname , email,pwd) VALUES ('$firstname','$email','$password');";

    $result = mysqli_query($con, $sql);
    if ($result) {
        echo " Ur Register Successfully...\n record save"; 
    }
    else
        {
        echo "error";
         }
}
        ?>
