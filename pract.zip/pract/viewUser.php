<?php 
#session_start();
#if(isset($_SESSION['loginid'])==1)
#{ 
?>

<!DOCTYPE html>
<html>
   <div class="header">
          <?php require './dashboard.php';?>  
        </div>
    
    <!--<div class="container col-md-8 col-md-offset-3 " style="margin-top: 50px;">
                <div class="row">
                <div class="col-md-6">
            <div class="search" >
                <form method="post" action="searchclient.php">
                <div class="form-group">
                    <label for="InputDname"> search by first name:</label>
                    <input type="text" name="firstname" class="form-control" id="Inputfname"  placeholder="Enter first name to search:">
                    <input type="submit" name="search" value="search">        
                </div>
               </form>  
            </div>
            </div>
                </div>
            </div>
    
  <div class=" col-md-offset-3" >
      <form method="post" action="viewUser.php">
                <input type='submit' value='View Client Detail' name='ViewClient'>
             </form>
        </div>-->
</html>

<?php
require './config.php';
require './dbconfig.php';
#require './bootstrap.php';
//echo '<a href="domain.php">view domain details</a>';
//if (isset($_POST['ViewClient'])) 
   // {
   // echo '   hiii';
    
    $query = "select * from login_tbl";
    $result_display = mysqli_query($con, $query);
    //echo "<table style='border:1px solid black' class = 'table-bordered table-condensed'>";
        echo "<div class='table-responsive'>";
         echo "<table class='table'>";
         echo ' <tr>';
         echo'<th>Firstname</th>';          
        echo'<th>email</th>';      
         echo'</tr>';
    while($row = mysqli_fetch_array($result_display))
    {
        echo "<tr style='border-bottom:1px solid black'>";
        echo "<td>" . $row['fname']  . "</td>"; 
        echo "<td>" . $row['email']  . "</td>"; 
       echo "<td><a href='user.php?id=".$row['loginid']."'>Update</a></td>";       
//the above the code is fetch the id in table and display record.
        echo "</tr>";
    }
     echo "</table>";
     echo "</div>";    
   // }
    echo " <a href='dashboard.php'><input type='button' value='back' name='back' ></a>";
?>


