<?php
#session_start();
#if(isset($_SESSION['loginid'])==1)
#{ 
#?>

<?php
     require 'config.php';
     require 'dbconfig.php';
     echo $_GET['id'];
     if(isset($_GET['id']))
         {
         //echo "hi";

$sql="SELECT * FROM login_tbl WHERE loginid = " . $_GET['id'];
		$result = mysqli_fetch_array(mysqli_query($con,$sql));
		$firstname = $result['fname']; 
		$email = $result['email']; 		
         }         
?>
<!DOCTYPE html>
<html>
     <head>
        <meta charset="UTF-8">
        <title>user Details</title>
        <link rel="stylesheet" href="css/bootstrap.css">
        <link rel="stylesheet" href="css/font-awesome.css">
        <link rel="stylesheet" href="fonts/glyphicons-halflings-regular.eot">
        <link rel="stylesheet" href="fonts/fontawesome-webfont.eot">
    </head>
    <div class="header">
          <?php require './dashboard.php';?>  
        </div>
    <form method="post" style="margin-top: 50px;">
<table align="center" cellpadding="5">
		<tr>
                <td>
		First Name:</td>
		<td>
                    <input type="text" name="fname" value="<?php echo $firstname;?>">
                    </td>
		</tr>
                
		<tr>
                <td>
		Email:</td>
		<td>	
                    <input type="email" name="email" value="<?php echo $email;?>"></td>
		</tr>
                
                <tr>
                <br> <td><a href='viewUser.php'><input type='button' value='back' name='back' >
                        </a>
                    
                
                    <input type="submit" value="update" name="update" >
                    <input type="submit" value="delete" name="delete" ></td>
                    
           <!--     <div class="form-group">
             <button type="submit" name="submit" class="btn btn-default">Submit</button>
                         </div>-->

                </tr>
		</table>
    </form>
   
</html>

<?php
 if(isset($_POST['update']))
    {       
   $id=$_GET['id'];
    $firstname = $_POST['fname'];    
    $email=$_POST['email'];
    //echo 'hiiiiii';
 $sqlupdate="update login_tbl set fname='$firstname', email='$email' WHERE loginid='$id'";
                      
     $result = mysqli_query($con, $sqlupdate);
    if ($result) 
        {
     echo 'record updated successfully';                    
        }
        else 
        { 
        echo 'error'; 
        }
            
}
if(isset($_POST['delete']))
    {       
   $id=$_GET['id'];
   
    //echo 'hiiiiii';
  $sqlupdate="DELETE from login_tbl WHERE loginid='$id'";
                      
     $result = mysqli_query($con, $sqlupdate);
    if ($result) 
        {
     echo 'record deleted successfully';                    
        }
        else 
        { 
        echo 'error'; 
        }
            
}

?>