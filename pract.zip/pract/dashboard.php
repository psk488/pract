<?php
session_start();
?>
<html>
	<head>
		<meta charset="utf-8">		
		<title>User Login</title>
		<meta name="description" content="">
		<meta name="author" content="">
		<link rel="stylesheet" href="css/index.css"  />
	</head>

<body>
    
   <div class="col-md-offset-4"  style="border:1px solid; box-shadow:5px 5px 5px #888777; width:400px; align:center;"> 
<table border="0" cellpadding="10" cellspacing="1" width="500" align="center">
<tr class="tableheader">
<td>Practice session example</td>
</tr>
<tr class="tablerow">
<td>
<?php
   // echo '<pre>';
    //print_r($_SESSION);
if($_SESSION["email"]) {
?>
    Welcome <?php echo $_SESSION["email"]; ?><br/> Click here to <a href="logout.php" title="Logout">Logout.</a>
    <br><br> 
    <a href="viewUser.php">View all users</a>
<?php
}
?>
</td>
</tr>
</table>
   </div>
</body>
</html>