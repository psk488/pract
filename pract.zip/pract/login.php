<!DOCTYPE html>
<html lang="en">
    <head>

        <meta charset="UTF-8">
        <title>Login page</title>
    </head>

    <body>
        
       
        <h1 class="text-center">Login </h1>
                <form method="post">


                    <div class="form-group">
                        <label for="Inputusername">Email:</label> 
                        <input type="email" name="email" class="form-control" id="Inputusername" placeholder="Enter username"> 
                    </div>

                    <div class="form-group">
                        <label for="Inputpwd">Password:</label>
                        <input class="form-control" type="password" name="password" placeholder="Password">
                    </div>   

                    <div class="form-group">
                        <button type="submit" name="submit" class="btn btn-default">Submit</button>
                        <button type="reset" name="reset" class="btn btn-default">Reset</button>
                    </div>

                    <div class="form-group">                       
                        <a href="index.php">New User Click here</a>
                    </div>
                </form>

        </body>
</html>
<?php
require 'config.php';
require 'dbconfig.php';
$_SESSION['loginid']=0;//to set value into session
if (isset($_POST['submit']))
    {
    session_start();
    $message="";
    $_SESSION['loginid']=1;
  
    $result = mysqli_query($con,"SELECT * FROM login_tbl WHERE email='" . $_POST['email'] . "' and pwd = '".$_POST['password']."'");
	$row  = mysqli_fetch_array($result);
	if(is_array($row)) {
	$_SESSION["userid"] = $row[loginid];
	$_SESSION["email"] = $row[email];
} else {
$message = "Invalid Username or Password!";
}
}
if(isset($_SESSION["userid"])) {
header("Location:dashboard.php");
//header("Location:dashboard.php");
}
?>
    

  



