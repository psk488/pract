
<?php
/*  //array eg 
$subj=array('C','C++','PHP');
 echo "I  Like ".$subj[0].",".$subj[1].",".$subj[2].".";
 */
//aritmatic eg
/*$cds = 50;
$tapes = 60;
$total = $cds + $tapes;
echo "You have " . $cds . " cds and " . $tapes
. " tapes with " . $total . " items!";
echo '<br>';
$total = $cds - $tapes;
echo "You have " . $cds . " cds and " . $tapes." tapes with " . $total . " items!";echo '<br>';
$total = $cds / $tapes;
echo "You have " . $cds . " cds and " . $tapes." tapes with " . $total . " items!";echo '<br>';
$total = $cds * $tapes;
echo "You have " . $cds . " cds and " . $tapes." tapes with " . $total . " items!";echo '<br>';


/*for($i=1;$i<=10;$i++)//it will print 1to10 no 
{
echo $i . "<br />";
}
*/
/*  //while-loop
$age = 1;
while($age < 18) {
echo "You are age " . $age . " and still not an adult<br />";
$age++;
}
echo "You are now an adult!";
*/

/* //switch eg
$choice = 3;
switch($choice) {
case 1:
echo "You picked choice #1 - well done!";
break;
case 2:
echo "You picked choice #2 - well done!";
break;
case 3:
echo "You picked choice #3 - well done!";
break;
default:
echo "You did not pick a valid choice!";
break;
}
*/ 
/* //function eg
function chk_max($v1,$v2)
	{
	   if($v1>$v2)
	    return($v1);
	    else
	     return ($v2);
	}
        echo 'max_no is:';    
echo ($ans=chk_max(10,20));
//echo '$ans';
 
*/
//String function
/* // substr()
$v1="PHP Programming";
$v2="hello world";
	      $ans=substr($v1,4,5);//it skips 1st 4 char.n display next 5 char(here whitespace also considered)
              $ans1=substr($v2,4);//it skip first 4 char.and display remaing string
	      printf("The substring is: %s",$ans);
              echo '<br>';
               printf("The substring is: %s",$ans1);
               */
/*  //substr_count()
$str="I am PHP Programmer";
$count=substr_count($str,"am");
print("the word am occurs $count times.");
 * */
 
/* //strrev
print strrev("hello world");
*/
echo '<br>';
print str_repeat('*', 40);
?>