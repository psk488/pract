<?php
session_start();
unset($_SESSION["loginid"]);//unset is used to remove data from session
unset($_SESSION["email"]);
header("Location:index.php");//used for redirection
?>